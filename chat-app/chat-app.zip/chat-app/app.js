// Import required modules
const express = require('express');
const path = require('path');
const { Socket } = require('socket.io');

// Create an Express application
const app = express();

// Define the port to listen on, using environment variable or default to 4000
const PORT = process.env.PORT || 4000;

// Start the server and listen on the specified port
const server = app.listen(PORT, () => console.log(`Server on port ${PORT}`));

// Initialize Socket.IO with the server
const io = require('socket.io')(server);

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Set to keep track of connected sockets
let socketsConnected = new Set();

// Handle connection events
io.on('connection', onConnected);

// Function to handle a new socket connection
function onConnected(socket) {
    // Log the unique socket ID when a new connection is established
    console.log(socket.id);

    // Add the socket ID to the set of connected sockets
    socketsConnected.add(socket.id);

    // Emit the total number of connected clients to all clients
    io.emit('clients.total', socketsConnected.size);

    // Handle disconnect event
    socket.on('disconnect', () => {
        console.log('Socket Disconnected', socket.id);

        // Remove the disconnected socket from the set
        socketsConnected.delete(socket.id);

        // Emit the updated total number of connected clients to all clients
        io.emit('clients.total', socketsConnected.size);
    });

    // Handle incoming messages
    socket.on('message', (data) => {
        console.log(data);

        // Broadcast the message to all clients except the sender
        socket.broadcast.emit('chat-message', data);
    });

    // Handle feedback events
    socket.on('feedback', (data) => {
        // Broadcast the feedback to all clients except the sender
        socket.broadcast.emit('feedback', data);
    });
}
