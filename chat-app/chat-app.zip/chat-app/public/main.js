// Initialize Socket.IO
const socket = io();

// Display total clients count
socket.on('clients.total', (data) => {
    console.log(data);
    clientsTotal.innerText = `User: ${data}`;
});

// DOM elements
const clientsTotal = document.getElementById('clients-total');
const messageContainer = document.getElementById('message-container');
const nameInput = document.getElementById('name-input');
const messageForm = document.getElementById('message-form');
const messageInput = document.getElementById('message-input');
const messageTone = new Audio('/message.mp3');

// Event listener for message form submission
messageForm.addEventListener('submit', (e) => {
    e.preventDefault();
    sendMessage();
});

// Function to send a message
function sendMessage() {
    if (messageInput.value == '') return;

    const data = {
        name: nameInput.value,
        message: messageInput.value,
        dateTime: new Date()
    };

    // Emit 'message' event to the server
    socket.emit('message', data);

    // Add the sent message to the UI
    addMessageToUI(true, data);

    // Clear the message input
    messageInput.value = '';
}

// Listen for incoming chat messages
socket.on('chat-message', (data) => {
    // Play a message tone
    messageTone.play();

    // Add the received message to the UI
    addMessageToUI(false, data);
});

// Function to add a message to the UI
function addMessageToUI(isOwnMessage, data) {
    clearFeedback();

    // Get the current date and time
    const formattedDateTime = new Date();

    // Customize the date and time format
    const options = { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', hour12: true };
    const formattedDateTimeString = formattedDateTime.toLocaleString('en-US', options);

    // Construct the message element
    const element = `
    <li class="${isOwnMessage ? 'message-right' : 'message-left'}">
        <p class="message">
            ${data.message} <span>${data.name} <br> ${formattedDateTimeString}</span>
        </p>
    </li>`;

    // Append the message to the message container
    messageContainer.innerHTML += element;

    // Scroll to the bottom of the message container
    scrollToBottom();
}

// Function to scroll to the bottom of the message container
function scrollToBottom() {
    messageContainer.scrollTo(0, messageContainer.scrollHeight);
}

// Event listeners for input focus, keypress, and blur
messageInput.addEventListener('focus', (e) => {
    // Emit 'feedback' event when the input is focused
    socket.emit('feedback', {
        feedback: `${nameInput.value} is typing`,
    });
});

messageInput.addEventListener('keypress', (e) => {
    // Emit 'feedback' event on keypress
    socket.emit('feedback', {
        feedback: `${nameInput.value} is typing`,
    });
});

messageInput.addEventListener('blur', (e) => {
    // Emit 'feedback' event when the input loses focus
    socket.emit('feedback', {
        feedback: '',
    });
});

// Listen for incoming feedback events
socket.on('feedback', (data) => {
    // Clear existing feedback messages and add the new one
    clearFeedback();
    const element = `
    <li class="message-feedback">
        <p class="feedback" id="feedback"> ${data.feedback}</p>
    </li>`;
    messageContainer.innerHTML += element;
});

// Function to clear feedback messages
function clearFeedback() {
    document.querySelectorAll('li.message-feedback').forEach((element) => {
        element.parentNode.removeChild(element);
    });
}
